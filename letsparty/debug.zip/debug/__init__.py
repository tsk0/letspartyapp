from django.forms import *
from django.forms.widgets import *
from letspartyapp.models import *
from LPTools.model_tools import *


def showattr(obj):
    """Visualizza la lista degli oggetti"""
    for attr in dir(obj):
        if not attr.startswith('__'):
            print attr
